<?php
$dbHost = 'Localhost';
$dbUsername = 'root';
$dbPassword = 'root';
$dbName = 'dashboard';

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

 ?>